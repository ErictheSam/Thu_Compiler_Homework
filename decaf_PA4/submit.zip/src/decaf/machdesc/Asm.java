package decaf.machdesc;

public abstract class Asm {
	public abstract String toString();
}
